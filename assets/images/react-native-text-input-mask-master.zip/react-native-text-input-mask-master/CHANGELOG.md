## Changelog

### Version 2.0.0

* Updated the headers in `RNTextInputMask.m` file to work with pods integration
